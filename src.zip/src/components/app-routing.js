import React from 'react';
import { Routes, Route } from "react-router-dom";
import Home from './home/home.js';
import User from "./user/user"
import Games from './games/games';
import Help from './help/help.js';
import Shop from './shop/shop.js';
import About from "./about/about"
class App extends React.Component{

  render() {
 
    return (
      <Routes>
        <Route index element={<Home />} />
        <Route path="About/" element={<About />} />
        <Route path="Games/" element={<Games />} />
        <Route path='Help/' element={<Help />} />
        <Route path='Shop/' element={<Shop />} /> 
        <Route path='User/' element={<User />} />
      </Routes>

    )
  }     

}

export default App;