import React, {Component} from "react";

function about() {
    return (
      <div>
        <h2>about</h2>
      </div>
    );
  }

  export default about
